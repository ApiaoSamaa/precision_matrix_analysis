import numpy as np

p = 20
precision_matrix = np.zeros()